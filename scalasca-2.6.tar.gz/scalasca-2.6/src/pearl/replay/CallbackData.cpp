/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include <config.h>

#include <pearl/CallbackData.h>

using namespace pearl;


// --- Constructors & destructor --------------------------------------------

CallbackData::~CallbackData()
{
}


// --- Pre- and postprocessing ----------------------------------------------

void
CallbackData::preprocess(const Event& event)
{
}


void
CallbackData::postprocess(const Event& event)
{
}
